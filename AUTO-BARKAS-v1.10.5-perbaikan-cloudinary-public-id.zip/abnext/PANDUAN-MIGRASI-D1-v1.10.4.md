# AUTO BARKAS v1.10.5 — Migrasi D1 wajib

Tindakan admin **Tandai Terjual** dan **Hapus dari Beranda** memakai tabel `payment_archive` dan `cleanup_jobs`. Audit sebelumnya menunjukkan kedua tabel belum ada di database. Karena itu, tombol dapat menampilkan konfirmasi tetapi proses API gagal saat menyimpan perubahan.

## Jalankan sekali sebelum menguji tombol admin

1. Buka Cloudflare Dashboard → Workers & Pages → D1 → `auto-barkas-db`.
2. Buka Console.
3. Salin dan jalankan seluruh isi `migrations-v1.10.sql` dari paket ini.
4. Pastikan perintah selesai tanpa error. Skrip menggunakan `CREATE TABLE IF NOT EXISTS` dan tidak menghapus atau mengubah baris iklan/pembayaran yang sudah ada.
5. Muat ulang panel admin dan uji pada iklan uji yang memang boleh diproses.

Jangan menjalankan perintah DROP, DELETE massal, atau memulihkan bookmark database. Migrasi ini hanya membuat tabel arsip pembayaran dan antrean pembersihan beserta indeksnya.
