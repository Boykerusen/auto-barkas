-- AUTO BARKAS v1.8: jalankan di D1 Console satu kali.
-- Jika ALTER menyatakan kolom sudah ada, hapus baris ALTER terkait lalu jalankan ulang sisanya.
ALTER TABLE listings ADD COLUMN plan TEXT DEFAULT '30';
ALTER TABLE listings ADD COLUMN duration_days INTEGER DEFAULT 30;
ALTER TABLE listings ADD COLUMN starts_at TEXT;
ALTER TABLE listings ADD COLUMN rejected_at TEXT;
CREATE TABLE IF NOT EXISTS admin_audit (id TEXT PRIMARY KEY, payment_id TEXT NOT NULL, action TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE INDEX IF NOT EXISTS idx_payments_status ON payments(status);
CREATE INDEX IF NOT EXISTS idx_listings_status_expiry ON listings(status, expires_at);
CREATE INDEX IF NOT EXISTS idx_listings_rejected_at ON listings(status, rejected_at);
