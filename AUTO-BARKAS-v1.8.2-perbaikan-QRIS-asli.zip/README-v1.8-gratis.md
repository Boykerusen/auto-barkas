# AUTO BARKAS v1.8 — verifikasi manual tanpa R2

## Perubahan
- Pengajuan iklan tidak meminta atau menyimpan foto bukti pembayaran.
- Admin memeriksa transaksi pada rekening/aplikasi QRIS sendiri, lalu setujui atau tolak.
- Penolakan menyimpan status 24 jam melalui `rejected_at`, lalu cron menghapus listing dan data terkait.
- Iklan aktif yang kedaluwarsa 3 hari lalu dihapus bersama foto, spesifikasi, tayangan, dan pembayaran.
- Worker memakai D1 yang sudah ada; tidak membutuhkan binding R2/PROOFS.

## Penting sebelum deploy
1. Backup D1 terlebih dahulu melalui Cloudflare Time Travel/bookmark atau ekspor yang tersedia.
2. Buka Cloudflare D1 Console dan jalankan `migrations-v1.8.sql`. Jika kolom sudah ada, hapus baris ALTER yang duplikat lalu jalankan kembali. Jangan jalankan ALTER yang sama dua kali.
3. Ganti kode Worker aktif dengan `worker-api.js`. Pertahankan secrets `ADMIN_PASSWORD` dan `ADMIN_TOKEN_SECRET` serta binding `DB`. Jangan menambahkan R2.
4. Aktifkan cron `0 * * * *` pada Worker (Settings/Triggers/Cron Triggers) agar fungsi `scheduled` berjalan tiap jam. Jika mengelola Worker melalui dashboard, tambahkan jadwal Cron Trigger di dashboard; file wrangler.toml hanya berlaku bila deploy memakai Wrangler.
5. Deploy Worker, lalu deploy website dari ZIP ini melalui alur GitHub Actions yang sudah digunakan.
6. Uji pengajuan dengan data percobaan, login `/admin.html`, verifikasi endpoint, dan cek website publik. Jangan mengaktifkan iklan sebelum pembayaran nyata cocok.

## Catatan kompatibilitas
- Database lama mungkin sudah mempunyai kolom `proof_key` dari versi sebelumnya. Kolom itu boleh tetap ada dan tidak lagi digunakan; jangan hapus kolom secara manual.
- Kode ini menghapus data terkait berdasarkan `listing_id`. Jadwal pembersihan memproses maksimal 200 iklan per eksekusi.
- Cron dan Worker harus berhasil di-deploy agar pembersihan otomatis berjalan. Tanpa Cron Trigger, data tidak terhapus otomatis.
- Jangan pernah memasukkan kata sandi/token ke file ZIP atau GitHub.
- QRIS pada halaman tetap placeholder sampai gambar QRIS resmi diganti. Jangan meminta pengiklan membayar ke gambar placeholder.
