-- Jalankan satu kali pada D1 yang dipakai AUTO BARKAS.
-- Jika D1 melaporkan kolom sudah ada, hapus baris ALTER yang sesuai lalu jalankan ulang.
ALTER TABLE listings ADD COLUMN plan TEXT DEFAULT '30';
ALTER TABLE listings ADD COLUMN duration_days INTEGER DEFAULT 30;
ALTER TABLE listings ADD COLUMN starts_at TEXT;
ALTER TABLE payments ADD COLUMN proof_key TEXT;
ALTER TABLE payments ADD COLUMN verified_at TEXT;
CREATE TABLE IF NOT EXISTS admin_audit (
 id TEXT PRIMARY KEY,
 payment_id TEXT NOT NULL,
 action TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_payments_status ON payments(status);
CREATE INDEX IF NOT EXISTS idx_listings_status_expiry ON listings(status, expires_at);
