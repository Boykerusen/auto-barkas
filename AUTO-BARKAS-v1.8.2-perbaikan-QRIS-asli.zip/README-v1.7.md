# AUTO BARKAS v1.7
Pembaruan panel admin, verifikasi pembayaran manual QRIS, penghapusan bukti transfer, dan masa tayang iklan.

**Penting:** ZIP ini menyiapkan kode frontend dan Worker. Fitur admin memerlukan setup Cloudflare Worker secrets, private R2 bucket binding `PROOFS`, dan migrasi D1. Ikuti `PETUNJUK-v1.7.txt`. Slot QRIS adalah placeholder, bukan QRIS pembayaran.

## Berkas utama
- `index.html`, `app.js`, `styles.css`: website dan formulir pembayaran.
- `admin.html`, `admin.js`: panel admin.
- `worker-api.js`: API Worker.
- `migrations-v1.7.sql`: migrasi skema D1.
- `qris-placeholder.svg`: slot QRIS sementara.
