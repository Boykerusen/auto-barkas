# AUTO BARKAS v1.13.0 — 3D Cinematic World

Pembaruan **visual saja** dari v1.12.4. Dunia marketplace otomotif bergaya miniatur animasi CGI (Pixar/Disney):

- Logo, navigasi, dan tombol glossy 3D dengan efek tekan.
- Hero sinematik: matahari, awan melayang, bukit hijau, dan koleksi barang di atas panggung putar.
- Kategori sebagai kios pasar mini dengan tenda bergaris.
- Harga dan paket iklan sebagai objek 3D (blok + koin harga).
- Formulir pasang iklan sebagai meja kerja miniatur (kertas, selotip, pensil).
- Footer 3D berupa tanah berumput.
- Palet: hijau pastel, kuning, putih, aksen hangat. Responsif Android dan desktop.
- Animasi ringan (hanya transform/translate) dan menghormati `prefers-reduced-motion`.

## Yang berubah
- `styles.css`: lapisan baru "v1.13.0" ditambahkan di bagian paling akhir. Lapisan lama tidak dihapus.
- `VERSION.txt`, `package.json` (nomor versi/deskripsi), dan file catatan ini.

## Yang TIDAK berubah (identik byte-per-byte dengan v1.12.4)
`index.html`, `admin.html`, `app.js`, `admin.js`, `worker-api.js`, `wrangler.toml`, `migrations-*.sql`,
`favicon.svg`, `public_marketplace-hero.png`, `qris-barkas-batusangkar.png`.

## Build
`npm run build` (tidak berubah) menyalin berkas ke `dist/`. Cloudflare Pages memakai `dist`.
Tidak ada deployment otomatis yang dilakukan pada paket ini.

## Catatan font
Font Baloo 2 dan Nunito dimuat dari Google Fonts (sudah ada sejak v1.12.4). Bila gagal dimuat, tampilan memakai font sistem.
