(() => {
  "use strict";
  const API_BASE = "https://auto-barkas-db.daboykrsn.workers.dev";
  const overlay = document.getElementById("announcementOverlay");
  const img = document.getElementById("announcementImage");
  const close = document.getElementById("closeAnnouncement");
  const SHOW_EVERY_VISIT = false;
  let closed = false;
  try { closed = sessionStorage.getItem("autoBarkasInfoClosed") === "yes"; } catch (e) {}
  function hide() {
    overlay.hidden = true;
    try { sessionStorage.setItem("autoBarkasInfoClosed", "yes"); } catch (e) {}
  }
  img.addEventListener("load", () => { if (SHOW_EVERY_VISIT || !closed) overlay.hidden = false; }, { once: true });
  img.addEventListener("error", () => { overlay.hidden = true; });
  close.addEventListener("click", hide);
  overlay.addEventListener("click", (e) => { if (e.target === overlay) hide(); });
  document.addEventListener("keydown", (e) => { if (e.key === "Escape" && !overlay.hidden) hide(); });

  const toggle = document.getElementById("menuToggle");
  const nav = document.getElementById("nav");
  toggle.addEventListener("click", () => {
    const open = nav.classList.toggle("open");
    toggle.setAttribute("aria-expanded", String(open));
  });
  nav.querySelectorAll("a").forEach((a) => a.addEventListener("click", () => {
    nav.classList.remove("open"); toggle.setAttribute("aria-expanded", "false");
  }));
  const yearNode = document.getElementById("year"); if (yearNode) yearNode.textContent = new Date().getFullYear();

  const form = document.getElementById("searchForm");
  const searchInput = document.getElementById("searchInput");
  const locationInput = document.getElementById("location");
  const message = document.getElementById("searchMessage");
  const results = document.getElementById("listingResults");
  let allListings = [];

  function text(value, fallback = "") {
    return value === null || value === undefined || value === "" ? fallback : String(value);
  }
  function formatPrice(value) {
    const amount = Number(value);
    return Number.isFinite(amount) ? new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", maximumFractionDigits: 0 }).format(amount) : "Hubungi penjual";
  }
  function makeCard(item) {
    const card = document.createElement("article"); card.className = "listing-card";
    const heading = document.createElement("h3"); heading.textContent = text(item.title, "Barang tanpa judul");
    const price = document.createElement("strong"); price.className = "listing-price"; price.textContent = formatPrice(item.price);
    const meta = document.createElement("p"); meta.className = "listing-meta";
    meta.textContent = [text(item.category), text(item.condition), [text(item.district), text(item.regency), text(item.province)].filter(Boolean).join(", ")].filter(Boolean).join(" • ");
    const desc = document.createElement("p"); desc.className = "listing-description"; desc.textContent = text(item.description, "Tidak ada deskripsi barang.");
    const photos=Array.isArray(item.photos)?item.photos:[];
    if(photos.length){const gallery=document.createElement("div");gallery.className="card-photos";photos.forEach((url,index)=>{const photo=document.createElement("img");photo.src=url;photo.alt=`${item.title} - foto ${index+1}`;photo.loading="lazy";photo.addEventListener("click",()=>window.open(url,"_blank","noopener"));gallery.append(photo);});card.append(gallery);}
    card.append(heading, price, meta, desc);
    if(item.seller_contact){const contact=document.createElement("a");contact.className="btn primary seller-contact";contact.href=`https://wa.me/${String(item.seller_contact).replace(/\D/g,"")}`;contact.target="_blank";contact.rel="noopener";contact.textContent="Hubungi penjual via WhatsApp";card.append(contact);}
    return card;
  }
  function render(items) {
    results.replaceChildren();
    if (!items.length) {
      const empty = document.createElement("div"); empty.className = "empty";
      const title = document.createElement("h3"); title.textContent = "Belum ada iklan yang cocok";
      const detail = document.createElement("p"); detail.textContent = allListings.length ? "Coba kata kunci atau lokasi lain." : "Belum ada iklan aktif yang disetujui untuk ditampilkan.";
      empty.append(title, detail); results.append(empty); return;
    }
    const grid = document.createElement("div"); grid.className = "listing-grid";
    items.forEach(item => grid.append(makeCard(item)));
    results.append(grid);
  }
  function filterListings() {
    const q = searchInput.value.trim().toLocaleLowerCase("id");
    const loc = locationInput.value.trim().toLocaleLowerCase("id");
    const filtered = allListings.filter(item => {
      const haystack = [item.title, item.description, item.category, item.subcategory, item.regency, item.district, item.village, item.province].map(v => text(v)).join(" ").toLocaleLowerCase("id");
      const location = [item.regency, item.district, item.village, item.province].map(v => text(v)).join(" ").toLocaleLowerCase("id");
      return (!q || haystack.includes(q)) && (!loc || location.includes(loc));
    });
    message.textContent = `Menampilkan ${filtered.length} dari ${allListings.length} iklan aktif.`;
    render(filtered);
  }
  async function loadListings() {
    message.textContent = "Mengambil daftar iklan dari server…";
    try {
      const response = await fetch(`${API_BASE}/api/listings`, { headers: { Accept: "application/json" } });
      if (!response.ok) throw new Error("API response error");
      const data = await response.json();
      if (!data || data.success !== true || !Array.isArray(data.listings)) throw new Error("Format data tidak sesuai");
      allListings = data.listings;
      filterListings();
    } catch (error) {
      message.textContent = "Daftar iklan belum dapat dimuat. Periksa koneksi internet dan coba muat ulang.";
      results.replaceChildren();
      const box = document.createElement("div"); box.className = "empty";
      const title = document.createElement("h3"); title.textContent = "Belum bisa terhubung ke daftar iklan";
      const detail = document.createElement("p"); detail.textContent = "Silakan coba lagi beberapa saat. Situs tetap dapat dibuka, tetapi hasil iklan belum tersedia.";
      const retry = document.createElement("button"); retry.type = "button"; retry.className = "btn primary"; retry.textContent = "Coba lagi"; retry.addEventListener("click", loadListings);
      box.append(title, detail, retry); results.append(box);
    }
  }
  form.addEventListener("submit", (e) => { e.preventDefault(); filterListings(); });
  document.querySelectorAll("[data-category]").forEach((a) => a.addEventListener("click", () => {
    searchInput.value = a.dataset.category;
    setTimeout(filterListings, 0);
  }));
  const listingForm = document.getElementById("listingForm");
  const listingFormMessage = document.getElementById("listingFormMessage");
  const submitListing = document.getElementById("submitListing");

  // Compress payment proof in the browser before upload; the original photo stays on the user's device.
  function compressPaymentProof(file, maxBytes = 500 * 1024) {
    return new Promise((resolve, reject) => {
      const objectUrl = URL.createObjectURL(file);
      const image = new Image();
      image.onload = () => {
        try {
          const maxSide = 1600;
          const scale = Math.min(1, maxSide / Math.max(image.naturalWidth, image.naturalHeight));
          const canvas = document.createElement("canvas");
          canvas.width = Math.max(1, Math.round(image.naturalWidth * scale));
          canvas.height = Math.max(1, Math.round(image.naturalHeight * scale));
          const ctx = canvas.getContext("2d", { alpha: false });
          if (!ctx) throw new Error("Browser tidak mendukung kompresi gambar.");
          ctx.fillStyle = "#ffffff";
          ctx.fillRect(0, 0, canvas.width, canvas.height);
          ctx.drawImage(image, 0, 0, canvas.width, canvas.height);
          URL.revokeObjectURL(objectUrl);
          let quality = 0.82;
          const encode = () => canvas.toBlob((blob) => {
            if (!blob) { reject(new Error("Gambar tidak dapat diproses. Coba pilih gambar lain.")); return; }
            if (blob.size <= maxBytes || quality <= 0.42) {
              if (blob.size > maxBytes) {
                reject(new Error("Bukti masih terlalu besar setelah dikompres. Pilih screenshot atau foto yang lebih kecil."));
                return;
              }
              const reader = new FileReader();
              reader.onload = () => resolve({ dataUrl: reader.result, size: blob.size });
              reader.onerror = () => reject(new Error("Bukti gagal dibaca."));
              reader.readAsDataURL(blob);
              return;
            }
            quality = Math.max(0.42, quality - 0.1);
            encode();
          }, "image/jpeg", quality);
          encode();
        } catch (error) {
          URL.revokeObjectURL(objectUrl);
          reject(error);
        }
      };
      image.onerror = () => { URL.revokeObjectURL(objectUrl); reject(new Error("Gambar tidak dapat dibuka. Pilih JPG, PNG, atau WebP.")); };
      image.src = objectUrl;
    });
  }

  const photoInput=document.getElementById("listingPhotos");
  const photoPreview=document.getElementById("photoPreview");
  function compressListingPhoto(file){return new Promise((resolve,reject)=>{const url=URL.createObjectURL(file),image=new Image();image.onload=()=>{const scale=Math.min(1,2000/Math.max(image.naturalWidth,image.naturalHeight));const canvas=document.createElement("canvas");canvas.width=Math.max(1,Math.round(image.naturalWidth*scale));canvas.height=Math.max(1,Math.round(image.naturalHeight*scale));const ctx=canvas.getContext("2d");if(!ctx){URL.revokeObjectURL(url);reject(new Error("Kompresi foto tidak didukung browser."));return;}ctx.drawImage(image,0,0,canvas.width,canvas.height);URL.revokeObjectURL(url);canvas.toBlob(blob=>{if(!blob){reject(new Error("Foto gagal dikompres."));return;}if(blob.size>5*1024*1024){reject(new Error("Ukuran foto masih lebih dari 5 MB."));return;}resolve(blob);},"image/webp",0.88);};image.onerror=()=>{URL.revokeObjectURL(url);reject(new Error("Salah satu foto tidak dapat dibuka."));};image.src=url;});}
  photoInput.addEventListener("change",()=>{photoPreview.replaceChildren();const files=[...photoInput.files];if(files.length>5){photoInput.value="";photoPreview.textContent="Maksimal 5 foto.";return;}files.forEach(file=>{const img=document.createElement("img");img.alt=file.name;img.src=URL.createObjectURL(file);photoPreview.append(img);});});
  async function uploadListingPhotos(listingId,files){const urls=[];for(const file of files){const blob=await compressListingPhoto(file);const signedResponse=await fetch(`${API_BASE}/api/uploads/sign`,{method:"POST",headers:{"Content-Type":"application/json",Accept:"application/json"},body:JSON.stringify({listing_id:listingId})});const signed=await signedResponse.json();if(!signedResponse.ok||!signed.success)throw new Error(signed.error||"Gagal menyiapkan unggahan foto.");const form=new FormData();form.append("file",blob,"foto-barang.webp");form.append("api_key",signed.api_key);form.append("timestamp",String(signed.timestamp));form.append("folder",signed.folder);form.append("upload_preset",signed.upload_preset);form.append("signature",signed.signature);const upload=await fetch(`https://api.cloudinary.com/v1_1/${signed.cloud_name}/image/upload`,{method:"POST",body:form});const result=await upload.json();if(!upload.ok||!result.secure_url)throw new Error(result.error?.message||"Unggah foto ke penyimpanan gagal.");urls.push(result.secure_url);}if(urls.length){const save=await fetch(`${API_BASE}/api/listings/${listingId}/photos`,{method:"POST",headers:{"Content-Type":"application/json",Accept:"application/json"},body:JSON.stringify({photos:urls})});const saved=await save.json();if(!save.ok||!saved.success)throw new Error(saved.error||"Foto terunggah tetapi belum tersimpan ke iklan.");}return urls.length;}

  listingForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    listingFormMessage.textContent = "Mengirim data iklan…";
    submitListing.disabled = true;
    const formData = new FormData(listingForm);
    const selectedPhotos=[...(photoInput?.files||[])];
    if(selectedPhotos.length>5){listingFormMessage.textContent="Maksimal 5 foto.";submitListing.disabled=false;return;}
    const payload = Object.fromEntries(formData.entries());
    delete payload.photos;
    payload.price = Number(payload.price);
    try {
      listingFormMessage.textContent = "Mengirim pengajuan tanpa menyimpan bukti pembayaran…";
      const response = await fetch(`${API_BASE}/api/listings`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Accept: "application/json" },
        body: JSON.stringify(payload)
      });
      const data = await response.json();
      if (!response.ok || data.success !== true) throw new Error(data.error || "Data belum dapat disimpan.");
      let uploaded=0;
      if(selectedPhotos.length){listingFormMessage.textContent="Data iklan tersimpan. Mengompres dan mengunggah foto…";uploaded=await uploadListingPhotos(data.listing_id,selectedPhotos);}
      listingForm.reset(); photoPreview.replaceChildren();
      listingFormMessage.textContent = `Pengajuan diterima. Nomor iklan: ${data.listing_id}. ${uploaded} foto tersimpan. Status pembayaran: menunggu verifikasi admin. Nominal paket Rp${new Intl.NumberFormat("id-ID").format(data.amount)}. Simpan nomor ini untuk referensi.`;
    } catch (error) {
      listingFormMessage.textContent = error.message || "Data belum berhasil dikirim. Pastikan API sudah diperbarui, lalu coba lagi.";
    } finally {
      submitListing.disabled = false;
    }
  });
  const qrisDownload = document.querySelector('.qris-box a[download]');
  if (qrisDownload) {
    qrisDownload.addEventListener('click', async (event) => {
      event.preventDefault();
      const button = qrisDownload;
      const originalText = button.textContent;
      button.textContent = "Menyiapkan QRIS…";
      button.setAttribute("aria-busy", "true");
      try {
        const response = await fetch('/qris-barkas-batusangkar.png', { cache: 'no-cache' });
        const type = (response.headers.get('content-type') || '').toLowerCase();
        if (!response.ok || !type.includes('image/png')) {
          throw new Error('File QRIS belum tersedia dengan benar. Muat ulang halaman atau hubungi admin.');
        }
        const blob = await response.blob();
        if (!blob.size) throw new Error('File QRIS kosong.');
        const objectUrl = URL.createObjectURL(blob);
        const temp = document.createElement('a');
        temp.href = objectUrl;
        temp.download = 'QRIS-BARKAS-BATUSANGKAR.png';
        document.body.appendChild(temp);
        temp.click();
        temp.remove();
        setTimeout(() => URL.revokeObjectURL(objectUrl), 1500);
      } catch (error) {
        alert(error.message || 'QRIS gagal diunduh.');
      } finally {
        button.textContent = originalText;
        button.removeAttribute('aria-busy');
      }
    });
  }
  loadListings();
})();
