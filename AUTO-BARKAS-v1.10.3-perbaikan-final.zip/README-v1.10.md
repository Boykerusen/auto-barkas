# AUTO BARKAS v1.10.3.2

Paket perbaikan lanjutan untuk situs AUTO BARKAS. Tema modern pastel hijau, kuning, dan putih dipertahankan.

## Perubahan v1.10.3.2
- Nomor HP penjual ditampilkan sebagai informasi tersendiri pada setiap kartu iklan, disertai tombol Chat WhatsApp. Nomor asli ditampilkan; tautan WhatsApp dinormalisasi ke kode negara 62.
- Validasi penyimpanan foto kini memeriksa bahwa URL Cloudinary benar-benar berada di folder `auto-barkas/{listing_id}` yang sesuai, bukan hanya berasal dari akun Cloudinary yang sama.
- Jadwal Cron Worker menjadi setiap 15 menit agar waktu retry antrean (+15 menit) tidak tertunda sampai satu jam.
- Migrasi hanya menambahkan `payment_archive`, `cleanup_jobs`, dan indeks terkait jika belum tersedia. Tidak mengubah data iklan/pembayaran yang ada.
- Versi API ditandai 1.10.2.

## Kondisi database yang telah diperiksa
Pemeriksaan baca-saja oleh pemilik database menunjukkan tabel `listings`, `payments`, `listing_photos`, `listing_specs`, dan `listing_views` tersedia. Kolom `rejected_at`, `plan`, `duration_days`, dan `starts_at` sudah ada. Tabel `payment_archive` dan `cleanup_jobs` belum ada pada saat pemeriksaan. Indeks dasar listing dan views sudah ada. Jumlah data pada saat pemeriksaan: 2 iklan active, 3 pending; 2 pembayaran verified, 3 pending. Hubungan pembayaran: 3 pending→pending dan 2 verified→active.

## Urutan pemasangan yang aman
1. Simpan ZIP ini dan backup D1 yang sudah dibuat. Jangan restore bookmark Time Travel kecuali untuk pemulihan yang memang diperlukan.
2. Pastikan kembali database yang dipilih adalah `auto-barkas-db`.
3. Jalankan `migrations-v1.10.3.sql` satu kali di D1 Console. Skrip hanya membuat tabel/index yang belum ada. Jangan jalankan query DROP, DELETE, atau RESTORE.
4. Deploy `worker-api.js` ke Worker `auto-barkas-db`, pertahankan binding `DB` dan seluruh secrets/vars lama. Atur Cron menjadi `*/15 * * * *` (setiap 15 menit).
5. Uji endpoint status Worker, login admin, pengajuan iklan uji baru, upload foto, dan tampilan nomor HP. Uji tindakan hapus hanya pada iklan uji baru setelah memastikan foto tersebut bukan milik iklan lain.
6. Setelah Worker lolos uji, deploy file website ke Cloudflare Pages.

## Penghapusan dan arsip
- Aksi Tandai Terjual/Hapus dari Beranda tetap memerlukan konfirmasi admin di antarmuka.
- Iklan disembunyikan lebih dahulu. Pembayaran dipindahkan ke `payment_archive` dan baris pembayaran terkait dihapus agar relasi foreign key tidak menghalangi pembersihan.
- Foto dihapus dari Cloudinary melalui `cleanup_jobs`. Jika penghapusan gagal, data listing dipertahankan dalam status nonpublik dan pekerjaan dicoba ulang.
- Listing beserta data turunannya baru dihapus setelah foto berhasil dibersihkan.
- Arsip pembayaran dihapus setelah 24 jam.
- Pengajuan yang ditolak dijadwalkan untuk pembersihan setelah 24 jam.

## Konfigurasi rahasia
Jangan memasukkan `CLOUDINARY_API_SECRET`, `ADMIN_PASSWORD`, atau `ADMIN_TOKEN_SECRET` ke file ZIP, repository, atau frontend. Pertahankan rahasia yang sudah ada di pengaturan Worker.

## Batas verifikasi
Paket ini telah diperiksa sintaks dan isi ZIP secara lokal. Integrasi Cloudflare D1, Cloudinary, login admin, dan deployment live belum diuji dari lingkungan ini. Jangan menganggap migrasi atau deployment sudah dilakukan.


## v1.10.3 — deployment Pages + Worker
- Worker API routes include `/api/admin/listings` and public listing responses include `seller_contact`.
- `wrangler.toml` explicitly declares the existing D1 binding `DB` and database ID.
- Worker scheduled cleanup pauses safely if v1.10 tables are not yet migrated; it does not delete listings or payments when those tables are absent.
- Deploy Worker before Pages. Keep existing Worker secrets (`ADMIN_PASSWORD`, `ADMIN_TOKEN_SECRET`, `CLOUDINARY_API_KEY`, `CLOUDINARY_API_SECRET`, `CLOUDINARY_CLOUD_NAME`) configured in Cloudflare.
- Apply `migrations-v1.10.sql` only after confirming a fresh D1 backup; until then destructive admin cleanup may return an error and must not be used.
