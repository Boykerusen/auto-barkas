# AUTO BARKAS — website v1.10.2

Prototipe responsif marketplace barang baru dan bekas. Tema hijau pastel, kuning pastel, putih. Sasaran awal Batusangkar/Tanah Datar dan rencana perluasan Sumatera Barat.

## Status fitur
Website terhubung ke Cloudflare Worker dan D1 untuk daftar iklan, pengajuan iklan, unggah foto Cloudinary, login admin, verifikasi pembayaran QRIS, aktivasi iklan, serta moderasi iklan. Nomor HP penjual ditampilkan pada kartu iklan dan tombol WhatsApp. Pastikan konfigurasi Worker, Cloudinary, dan migrasi D1 sudah sesuai sebelum digunakan di produksi.

## Popup gambar informasi
Letakkan gambar buatan sendiri di `public/images/informasi.jpg`. Untuk mengganti gambar, unggah file baru dengan nama yang sama melalui GitHub lalu commit. Popup memiliki tombol X, dapat ditutup dengan klik luar atau tombol Escape, dan jika gambar belum tersedia popup tidak muncul. Upload langsung dari website memerlukan panel admin/backend.

## Deploy gratis melalui GitHub dan Cloudflare Pages (tanpa Codespaces)
1. Ekstrak ZIP. Unggah **isi folder proyek** ke root repository GitHub `auto-barkas`.
2. Di Cloudflare buka Workers & Pages → Create → Pages → Connect to Git.
3. Pilih repository `auto-barkas`.
4. Build command: `npm run build`; output directory: `dist`.
5. Deploy dan uji alamat `*.pages.dev` dari HP.

## Paket rancangan
Hemat 7 hari Rp2.000 (usulan), Reguler 30 hari Rp5.000 (harga yang diminta), Panjang 60 hari Rp9.000 (usulan), Unggulan 30 hari Rp10.000 (usulan). Paket selain Reguler dapat diubah. Lihat `docs/PAKET-QRIS-DAN-KEAMANAN.md`.


## Perbaikan tampilan
Build terbaru menyalin `styles.css`, `app.js`, dan `favicon.svg` ke folder hasil build `dist`, dan HTML memakai jalur aset yang sesuai. Ini memperbaiki masalah CSS/JavaScript yang sebelumnya tidak ikut disalin ke hasil deployment.


## v1.5 Signature identity
- Redesigned BA brand mark with a stronger geometric badge, layered green finish, and gold accent.
- Refined wordmark typography and mobile sizing.
- Updated favicon to match the new BA signature mark.
- Preserves the existing listing form and API integration from v1.3.

## Konfigurasi Cloudinary (v1.9)
Di Cloudflare Worker `auto-barkas-db`, tambahkan Secrets/Variables berikut:
- `CLOUDINARY_API_SECRET` (Secret; sudah ditambahkan)
- `CLOUDINARY_API_KEY` (Text): API Key Cloudinary
- `CLOUDINARY_CLOUD_NAME` (Text): nama cloud Cloudinary
Upload preset `auto_barkas` harus Signed dan folder `auto-barkas`, dengan format jpg,jpeg,png,webp.
