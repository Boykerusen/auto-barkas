# AUTO BARKAS v1.9.1 – Perbaikan integrasi Worker dan foto admin

## Konfigurasi Worker yang diperlukan
- `CLOUDINARY_API_KEY` (Variable): API Key Cloudinary
- `CLOUDINARY_API_SECRET` (Secret): API Secret Cloudinary
- `CLOUDINARY_CLOUD_NAME` (Variable): `kelqxbib`
- `ADMIN_PASSWORD` (Secret)
- `ADMIN_TOKEN_SECRET` (Secret)
- D1 binding `DB` tetap menunjuk database `auto-barkas-db`.

## Deploy Worker
Gunakan file `worker-api.js` dari paket ini untuk mengganti source Worker `auto-barkas-db`. Jangan membuat D1 baru dan jangan menghapus binding DB. Setelah deploy, buka `https://auto-barkas-db.daboykrsn.workers.dev/` dan pastikan respons JSON menunjukkan `version: 1.9.1`.

## Perubahan
- Endpoint `/api/uploads/sign` menandatangani upload Cloudinary.
- Endpoint `/api/listings/:id/photos` menyimpan URL foto ke tabel `listing_photos` yang sudah ada.
- GET daftar iklan dan antrean admin menyertakan foto.
- Halaman admin menampilkan thumbnail foto.
- Cron tidak lagi menghapus data iklan, pembayaran, atau foto.

Jangan pernah memasukkan API Secret ke kode, ZIP, GitHub, atau chat.
