-- AUTO BARKAS v1.10.2
-- Menambahkan arsip pembayaran dan antrean pembersihan; aman dijalankan ulang.
-- Tidak mengubah/menghapus data listings atau payments yang sudah ada.
CREATE TABLE IF NOT EXISTS payment_archive (
  id TEXT PRIMARY KEY, listing_id TEXT NOT NULL, amount INTEGER NOT NULL,
  payment_method TEXT NOT NULL DEFAULT 'QRIS', status TEXT NOT NULL,
  created_at TEXT, verified_at TEXT, plan TEXT, duration_days INTEGER,
  archived_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, delete_after TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_payment_archive_delete_after ON payment_archive(delete_after);
CREATE TABLE IF NOT EXISTS cleanup_jobs (
  id INTEGER PRIMARY KEY AUTOINCREMENT, listing_id TEXT NOT NULL UNIQUE,
  public_ids TEXT NOT NULL, run_after TEXT NOT NULL, attempts INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_cleanup_jobs_run_after ON cleanup_jobs(run_after);
