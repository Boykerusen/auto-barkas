GAMBAR POPUP INFORMASI
Unggah gambar desain Anda dengan nama persis informasi.jpg ke folder public/images/.
Pada versi awal, gambar diganti melalui GitHub dengan mengganti file ini lalu commit/redeploy. Unggah langsung melalui website membutuhkan panel admin dan penyimpanan server yang belum tersedia.
Jika gambar belum ada, popup otomatis tidak ditampilkan.
