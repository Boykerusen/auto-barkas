(() => {
  "use strict";
  const API_BASE = "https://auto-barkas-db.daboykrsn.workers.dev";
  const overlay = document.getElementById("announcementOverlay");
  const img = document.getElementById("announcementImage");
  const close = document.getElementById("closeAnnouncement");
  const SHOW_EVERY_VISIT = false;
  let closed = false;
  try { closed = sessionStorage.getItem("autoBarkasInfoClosed") === "yes"; } catch (e) {}
  function hide() {
    overlay.hidden = true;
    try { sessionStorage.setItem("autoBarkasInfoClosed", "yes"); } catch (e) {}
  }
  img.addEventListener("load", () => { if (SHOW_EVERY_VISIT || !closed) overlay.hidden = false; }, { once: true });
  img.addEventListener("error", () => { overlay.hidden = true; });
  close.addEventListener("click", hide);
  overlay.addEventListener("click", (e) => { if (e.target === overlay) hide(); });
  document.addEventListener("keydown", (e) => { if (e.key === "Escape" && !overlay.hidden) hide(); });

  const toggle = document.getElementById("menuToggle");
  const nav = document.getElementById("nav");
  toggle.addEventListener("click", () => {
    const open = nav.classList.toggle("open");
    toggle.setAttribute("aria-expanded", String(open));
  });
  nav.querySelectorAll("a").forEach((a) => a.addEventListener("click", () => {
    nav.classList.remove("open"); toggle.setAttribute("aria-expanded", "false");
  }));
  document.getElementById("year").textContent = new Date().getFullYear();

  const form = document.getElementById("searchForm");
  const searchInput = document.getElementById("searchInput");
  const locationInput = document.getElementById("location");
  const message = document.getElementById("searchMessage");
  const results = document.getElementById("listingResults");
  let allListings = [];

  function text(value, fallback = "") {
    return value === null || value === undefined || value === "" ? fallback : String(value);
  }
  function formatPrice(value) {
    const amount = Number(value);
    return Number.isFinite(amount) ? new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", maximumFractionDigits: 0 }).format(amount) : "Hubungi penjual";
  }
  function makeCard(item) {
    const card = document.createElement("article"); card.className = "listing-card";
    const heading = document.createElement("h3"); heading.textContent = text(item.title, "Barang tanpa judul");
    const price = document.createElement("strong"); price.className = "listing-price"; price.textContent = formatPrice(item.price);
    const meta = document.createElement("p"); meta.className = "listing-meta";
    meta.textContent = [text(item.category), text(item.condition), [text(item.district), text(item.regency), text(item.province)].filter(Boolean).join(", ")].filter(Boolean).join(" • ");
    const desc = document.createElement("p"); desc.className = "listing-description"; desc.textContent = text(item.description, "Tidak ada deskripsi barang.");
    card.append(heading, price, meta, desc);
    return card;
  }
  function render(items) {
    results.replaceChildren();
    if (!items.length) {
      const empty = document.createElement("div"); empty.className = "empty";
      const title = document.createElement("h3"); title.textContent = "Belum ada iklan yang cocok";
      const detail = document.createElement("p"); detail.textContent = allListings.length ? "Coba kata kunci atau lokasi lain." : "Belum ada iklan aktif yang disetujui untuk ditampilkan.";
      empty.append(title, detail); results.append(empty); return;
    }
    const grid = document.createElement("div"); grid.className = "listing-grid";
    items.forEach(item => grid.append(makeCard(item)));
    results.append(grid);
  }
  function filterListings() {
    const q = searchInput.value.trim().toLocaleLowerCase("id");
    const loc = locationInput.value.trim().toLocaleLowerCase("id");
    const filtered = allListings.filter(item => {
      const haystack = [item.title, item.description, item.category, item.subcategory, item.regency, item.district, item.village, item.province].map(v => text(v)).join(" ").toLocaleLowerCase("id");
      const location = [item.regency, item.district, item.village, item.province].map(v => text(v)).join(" ").toLocaleLowerCase("id");
      return (!q || haystack.includes(q)) && (!loc || location.includes(loc));
    });
    message.textContent = `Menampilkan ${filtered.length} dari ${allListings.length} iklan aktif.`;
    render(filtered);
  }
  async function loadListings() {
    message.textContent = "Mengambil daftar iklan dari server…";
    try {
      const response = await fetch(`${API_BASE}/api/listings`, { headers: { Accept: "application/json" } });
      if (!response.ok) throw new Error("API response error");
      const data = await response.json();
      if (!data || data.success !== true || !Array.isArray(data.listings)) throw new Error("Format data tidak sesuai");
      allListings = data.listings;
      filterListings();
    } catch (error) {
      message.textContent = "Daftar iklan belum dapat dimuat. Periksa koneksi internet dan coba muat ulang.";
      results.replaceChildren();
      const box = document.createElement("div"); box.className = "empty";
      const title = document.createElement("h3"); title.textContent = "Belum bisa terhubung ke daftar iklan";
      const detail = document.createElement("p"); detail.textContent = "Silakan coba lagi beberapa saat. Situs tetap dapat dibuka, tetapi hasil iklan belum tersedia.";
      const retry = document.createElement("button"); retry.type = "button"; retry.className = "btn primary"; retry.textContent = "Coba lagi"; retry.addEventListener("click", loadListings);
      box.append(title, detail, retry); results.append(box);
    }
  }
  form.addEventListener("submit", (e) => { e.preventDefault(); filterListings(); });
  document.querySelectorAll("[data-category]").forEach((a) => a.addEventListener("click", () => {
    searchInput.value = a.dataset.category;
    setTimeout(filterListings, 0);
  }));
  const listingForm = document.getElementById("listingForm");
  const listingFormMessage = document.getElementById("listingFormMessage");
  const submitListing = document.getElementById("submitListing");
  listingForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    listingFormMessage.textContent = "Mengirim data iklan…";
    submitListing.disabled = true;
    const formData = new FormData(listingForm);
    const payload = Object.fromEntries(formData.entries());
    payload.price = Number(payload.price);
    try {
      const response = await fetch(`${API_BASE}/api/listings`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Accept: "application/json" },
        body: JSON.stringify(payload)
      });
      const data = await response.json();
      if (!response.ok || data.success !== true) throw new Error(data.error || "Data belum dapat disimpan.");
      listingForm.reset();
      listingFormMessage.textContent = `Data iklan berhasil dikirim dengan nomor ${data.listing_id}. Status: menunggu verifikasi. Nominal paket Rp${new Intl.NumberFormat("id-ID").format(data.amount)}. Ini belum merupakan pembayaran; tunggu petunjuk admin.`;
    } catch (error) {
      listingFormMessage.textContent = "Data belum berhasil dikirim. Pastikan API sudah diperbarui, lalu coba lagi. Tidak ada pembayaran yang dilakukan.";
    } finally {
      submitListing.disabled = false;
    }
  });
  loadListings();
})();
