# Roadmap

## Prototipe
- [x] Tema hijau pastel, kuning pastel, putih
- [x] Responsif untuk HP
- [x] Kategori barang baru/bekas dan pencarian contoh
- [x] Popup gambar informasi dengan tombol tutup
- [x] Paket iklan dan panduan QRIS

## Sebelum peluncuran nyata
- [ ] Backend/database dan akun admin/penjual
- [ ] Form iklan, unggah foto dan halaman detail iklan
- [ ] Pencarian dan filter nyata
- [ ] Pembayaran QRIS dengan verifikasi transaksi
- [ ] Aktivasi/kedaluwarsa iklan otomatis dan log audit
- [ ] Moderasi, pelaporan, blokir spam, kebijakan privasi dan syarat layanan
- [ ] Domain, sitemap, Search Console, backup dan pengujian keamanan
