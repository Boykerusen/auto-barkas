export default {
  async fetch(request, env) {
    const cors = {
      "Access-Control-Allow-Origin": "https://auto-barkas.pages.dev",
      "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Accept",
      "Content-Type": "application/json; charset=utf-8",
      "Vary": "Origin"
    };
    const reply = (body, status = 200) =>
      new Response(JSON.stringify(body), { status, headers: cors });
    if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: cors });
    const url = new URL(request.url);
    try {
      if (url.pathname === "/" || url.pathname === "/api") {
        return reply({ app: "AUTO BARKAS API", status: "online" });
      }
      if (url.pathname === "/api/listings" && request.method === "GET") {
        const category = url.searchParams.get("category");
        let sql = `SELECT id, title, description, category, subcategory, price,
          condition, province, regency, district, village, seller_name,
          created_at, expires_at, views
          FROM listings WHERE status = 'active'
          AND (expires_at IS NULL OR expires_at > CURRENT_TIMESTAMP)`;
        let stmt = env.DB.prepare(sql);
        if (category) stmt = env.DB.prepare(sql + " AND category = ?").bind(category);
        const result = await stmt.all();
        return reply({ success: true, listings: result.results });
      }
      if (url.pathname === "/api/listings" && request.method === "POST") {
        const origin = request.headers.get("Origin");
        if (origin !== "https://auto-barkas.pages.dev") {
          return reply({ success: false, error: "Asal permintaan tidak diizinkan." }, 403);
        }
        const contentType = request.headers.get("Content-Type") || "";
        if (!contentType.toLowerCase().includes("application/json")) {
          return reply({ success: false, error: "Gunakan format JSON." }, 415);
        }
        const data = await request.json();
        const clean = (v, max) => typeof v === "string" ? v.trim().slice(0, max) : "";
        const title = clean(data.title, 120);
        const category = clean(data.category, 60);
        const description = clean(data.description, 2000);
        const condition = clean(data.condition, 10);
        const province = clean(data.province, 80);
        const regency = clean(data.regency, 100);
        const district = clean(data.district, 100);
        const village = clean(data.village, 100);
        const sellerName = clean(data.seller_name, 100);
        const sellerContact = clean(data.seller_contact, 30);
        const price = Number(data.price);
        const plan = String(data.plan || "30");
        const plans = {
          "7": { amount: 2000, days: 7 },
          "30": { amount: 5000, days: 30 },
          "60": { amount: 9000, days: 60 },
          "featured": { amount: 10000, days: 30 }
        };
        if (!title || !category || !description || !["baru", "bekas"].includes(condition) ||
            !province || !regency || !sellerName || !sellerContact ||
            !Number.isSafeInteger(price) || price < 0 || price > 1000000000000 ||
            !plans[plan] || !/^[+0-9 ()-]{8,30}$/.test(sellerContact)) {
          return reply({ success: false, error: "Data belum lengkap atau formatnya tidak valid." }, 400);
        }
        const id = crypto.randomUUID();
        const paymentId = crypto.randomUUID();
        const amount = plans[plan].amount;
        await env.DB.prepare(`INSERT INTO listings
          (id,title,description,category,price,condition,province,regency,district,village,
           seller_name,seller_contact,status,expires_at)
          VALUES (?,?,?,?,?,?,?,?,?,?,?,?,'pending',NULL)`)
          .bind(id,title,description,category,price,condition,province,regency,district,village,
            sellerName,sellerContact).run();
        await env.DB.prepare(`INSERT INTO payments (id,listing_id,amount,payment_method,status)
          VALUES (?,?,?,'QRIS','pending')`).bind(paymentId,id,amount).run();
        return reply({
          success: true,
          listing_id: id,
          payment_id: paymentId,
          amount,
          plan,
          duration_days: plans[plan].days,
          status: "pending",
          message: "Data iklan diterima. Iklan belum tayang; pembayaran perlu diverifikasi admin."
        }, 201);
      }
      return reply({ success: false, error: "Endpoint tidak ditemukan." }, 404);
    } catch (error) {
      return reply({ success: false, error: "Terjadi kesalahan pada API." }, 500);
    }
  }
};
