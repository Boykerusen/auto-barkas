# SEO dan promosi

- Setelah domain ditentukan, atur canonical URL, Open Graph URL, sitemap, dan robots.txt.
- Daftarkan domain di Google Search Console dan kirim sitemap setelah halaman iklan nyata tersedia.
- Buat halaman kategori/lokasi yang unik dan bermanfaat; hindari halaman duplikat tipis.
- Bagikan tautan di komunitas WhatsApp/Facebook lokal sesuai aturan grup dan tanpa spam.
- Tampilkan aturan iklan, kebijakan privasi, kontak pengelola, cara melapor, dan tips transaksi aman.
- SEO tidak menjamin peringkat tertentu atau jumlah pengunjung; hasil memerlukan waktu.
