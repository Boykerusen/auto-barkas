# Paket iklan dan QRIS

- Hemat: 7 hari Rp2.000 (usulan)
- Reguler: 30 hari Rp5.000 (sesuai permintaan)
- Panjang: 60 hari Rp9.000 (usulan)
- Unggulan: 30 hari Rp10.000 (usulan; penempatan khusus tidak menjamin barang terjual)
- Tahunan: 365 hari Rp45.000 (usulan untuk dipertimbangkan)

QRIS statis tidak memberi notifikasi otomatis ke website. Alur aman: server membuat order ID dan nominal; website menampilkan QRIS dan nominal; penjual membayar; admin mencocokkan transaksi dengan riwayat resmi merchant; server mengaktifkan iklan hanya setelah verifikasi, mencatat admin/waktu, lalu menghitung masa tayang dan kedaluwarsa. Jangan aktifkan iklan hanya dari screenshot karena dapat dipalsukan atau digunakan ulang. Untuk otomasi, tanyakan ke bank/acquirer/penyedia QRIS tentang API/webhook resmi atau QRIS dinamis. Jangan pernah meminta PIN, password, atau OTP.

Transaksi barang tetap langsung antara penjual dan pembeli; situs hanya memungut biaya penempatan iklan. Perlu HTTPS, pembatasan akses admin, validasi unggahan, audit log, moderasi dan pelaporan.
