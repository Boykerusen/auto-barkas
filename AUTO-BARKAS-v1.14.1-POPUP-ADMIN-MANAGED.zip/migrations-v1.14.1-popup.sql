-- AUTO BARKAS v1.14.1
-- Aman dijalankan ulang. Tidak mengubah tabel iklan, foto iklan, atau pembayaran.
CREATE TABLE IF NOT EXISTS popup_settings (
  id INTEGER PRIMARY KEY CHECK (id = 1),
  image_url TEXT NOT NULL,
  public_id TEXT NOT NULL,
  is_active INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0,1)),
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS popup_cleanup_jobs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  public_id TEXT NOT NULL,
  run_after TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  attempts INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_popup_cleanup_jobs_run_after ON popup_cleanup_jobs(run_after);
