# AUTO BARKAS v1.14.1 — Popup Informasi Admin

## Perubahan
- Hero di halaman utama dihilangkan; pencarian dan daftar iklan tetap.
- Popup informasi memakai satu gambar aktif yang dikelola melalui panel admin.
- Upload gambar menggunakan folder Cloudinary `auto-barkas/popup`.
- Konfigurasi gambar/status disimpan pada tabel D1 `popup_settings`.
- Penggantian gambar memasukkan gambar lama ke antrean penghapusan Cloudinary (dicoba ulang setiap 15 menit).
- Penghapusan manual menghapus gambar Cloudinary terlebih dahulu; catatan D1 hanya dihapus setelah Cloudinary mengonfirmasi sukses.
- Sistem iklan, foto listing, pembayaran, autentikasi, dan masa tayang tidak diubah.

## Langkah wajib sebelum deploy
1. Buat backup D1 terlebih dahulu.
2. Jalankan seluruh isi `migrations-v1.14.1-popup.sql` satu kali pada database D1 `auto-barkas-db` yang sudah dipakai Worker.
3. Pastikan Worker sudah memiliki secrets Cloudinary yang sama seperti sebelumnya: `CLOUDINARY_API_KEY`, `CLOUDINARY_API_SECRET`, dan `CLOUDINARY_CLOUD_NAME`. Tidak membuat token Cloudflare baru.
4. Upload ZIP ini ke root repository GitHub.
5. Ubah `ZIP_FILE` pada workflow menjadi nama ZIP ini, lalu jalankan GitHub Actions.
6. Setelah Worker dan Pages berhasil deploy, login ke `/admin.html`, unggah satu gambar popup, preview, lalu aktifkan.

## Catatan
- Popup muncul maksimal sekali per sesi browser dan dapat ditutup dengan X, klik area luar, atau Escape.
- Jika tidak ada gambar aktif atau gambar gagal dimuat, halaman utama tetap dapat digunakan.
- Gambar popup yang diganti dibersihkan melalui antrean Cron. Gambar yang dihapus manual tidak menghapus data D1 jika Cloudinary gagal mengonfirmasi penghapusan.
