(() => {
 const API="https://auto-barkas-db.daboykrsn.workers.dev";const loginCard=document.getElementById("loginCard"),dashboard=document.getElementById("dashboard"),loginForm=document.getElementById("loginForm"),loginMessage=document.getElementById("loginMessage"),queue=document.getElementById("paymentQueue"),queueMessage=document.getElementById("queueMessage"),activeList=document.getElementById("activeListings"),activeMessage=document.getElementById("activeMessage"),popupForm=document.getElementById("popupForm"),popupFile=document.getElementById("popupImageFile"),popupPreview=document.getElementById("popupPreview"),popupActive=document.getElementById("popupActive"),popupMessage=document.getElementById("popupMessage"),savePopup=document.getElementById("savePopup"),deletePopup=document.getElementById("deletePopup");let token="";
 function normalizeWhatsApp(phone){let digits=String(phone||"").replace(/\D/g,"");if(digits.startsWith("0"))digits="62"+digits.slice(1);else if(digits.startsWith("8"))digits="62"+digits;return digits;}
 const el=(tag,cls,txt)=>{const n=document.createElement(tag);if(cls)n.className=cls;if(txt!==undefined)n.textContent=txt;return n};const money=n=>new Intl.NumberFormat("id-ID").format(Number(n)||0);
 function setLoggedIn(value){loginCard.hidden=value;dashboard.hidden=!value;}
 async function login(e){e.preventDefault();loginMessage.textContent="Memeriksa login…";try{const r=await fetch(API+"/api/admin/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({password:document.getElementById("adminPassword").value})});const d=await r.json();if(!r.ok||!d.success)throw Error(d.error||"Login gagal");token=d.token;document.getElementById("adminPassword").value="";setLoggedIn(true);await loadQueue();await loadActive();await loadPopup();}catch(e){loginMessage.textContent=e.message||"Tidak dapat login. Periksa konfigurasi Worker.";}}
 async function api(path,opts={}){const r=await fetch(API+path,{...opts,headers:{...(opts.headers||{}),Authorization:"Bearer "+token}});const d=await r.json();if(r.status===401){token="";setLoggedIn(false);throw Error(d.error||"Sesi habis, login kembali.");}if(!r.ok||!d.success)throw Error(d.error||"Permintaan gagal");return d;}
 async function loadQueue(){queue.replaceChildren();queueMessage.textContent="Memuat antrean pembayaran…";try{const d=await api("/api/admin/payments");if(!d.payments.length){queueMessage.textContent="Tidak ada pembayaran yang menunggu verifikasi.";return;}queueMessage.textContent=`${d.payments.length} pembayaran menunggu verifikasi.`;d.payments.forEach(p=>{const card=el("article","admin-card");card.append(el("span","status-pill","MENUNGGU VERIFIKASI"),el("h2","",p.title||"Iklan tanpa judul"),el("p","",`Pengiklan: ${p.seller_name||"—"}`),el("p","",`Kontak: ${p.seller_contact||"—"}`),el("p","",`Lokasi: ${p.regency||"—"}`),el("p","",`Paket: ${p.plan||"30"} • Nominal: Rp${money(p.amount)}`),el("p","small",`ID pembayaran: ${p.payment_id}`));if(Array.isArray(p.photos)&&p.photos.length){const gallery=el("div","admin-photo-gallery");p.photos.slice(0,5).forEach((url,index)=>{const a=el("a","admin-photo-link");a.href=url;a.target="_blank";a.rel="noopener";const img=el("img","admin-photo");img.src=url;img.alt=`Foto iklan ${p.title||"barang"} ${index+1}`;img.loading="lazy";a.append(img);gallery.append(a);});card.append(gallery);}else{card.append(el("p","small","Belum ada foto yang tersimpan untuk iklan ini."));}card.append(el("p","small","Periksa transaksi QRIS/rekening secara manual sebelum menyetujui. Jika meragukan, hubungi nomor WhatsApp pengiklan."));const actions=el("div","admin-actions");const approve=el("button","btn primary","Setujui & aktifkan");approve.type="button";approve.disabled=false;approve.addEventListener("click",()=>decide(p.payment_id,"approve",approve));const reject=el("button","btn danger","Tolak pengajuan");reject.type="button";reject.addEventListener("click",()=>decide(p.payment_id,"reject",reject));actions.append(approve,reject);card.append(actions);queue.append(card);});}catch(e){queueMessage.textContent=e.message||"Gagal memuat pembayaran.";}}
 async function loadActive(){if(!activeList)return;activeList.replaceChildren();activeMessage.textContent="Memuat iklan aktif…";try{const d=await api("/api/admin/listings");if(!d.listings.length){activeMessage.textContent="Belum ada iklan aktif.";return;}activeMessage.textContent=`${d.listings.length} iklan aktif.`;d.listings.forEach(item=>{const card=el("article","admin-card"),digits=normalizeWhatsApp(item.seller_contact);card.append(el("span","status-pill","AKTIF"),el("h2","",item.title),el("p","",`Harga: Rp${money(item.price)} • Lokasi: ${item.regency||"—"}`),el("p","",`Penjual: ${item.seller_name||"—"} • ${item.seller_contact||"—"}`),el("p","small",`Mulai: ${item.starts_at||"—"} • Berakhir: ${item.expires_at||"—"} • Dilihat: ${item.views||0}`));if(item.photos?.length){const gallery=el("div","admin-photo-gallery");item.photos.forEach((url,i)=>{const im=el("img","admin-photo");im.src=url;im.alt=`Foto ${i+1}`;gallery.append(im)});card.append(gallery);}if(digits){const wa=el("a","btn white","WhatsApp penjual");wa.href=`https://wa.me/${digits}`;wa.target="_blank";wa.rel="noopener";card.append(wa);}const actions=el("div","admin-actions");for(const [action,label] of [["sold","Tandai Terjual"],["remove","Hapus dari Beranda"]]){const b=el("button",action==="sold"?"btn primary":"btn danger",label);b.type="button";b.addEventListener("click",()=>manageListing(item,action,b));actions.append(b);}card.append(actions);activeList.append(card);});}catch(e){activeMessage.textContent=e.message||"Gagal memuat iklan aktif.";}}
 async function manageListing(item,action,button){const label=action==="sold"?"menandai iklan ini terjual":"menghapus iklan ini dari beranda";const detail=action==="sold"?"Iklan akan disembunyikan dari beranda sebagai terjual. Foto akan diproses untuk dihapus dan arsip pembayaran disimpan 24 jam.":"Iklan akan disembunyikan dari beranda. Foto akan diproses untuk dihapus dan arsip pembayaran disimpan 24 jam.";if(!confirm(`Anda yakin ${label}?\n\n${detail}`))return;button.disabled=true;try{const d=await api(`/api/admin/listings/${item.id}/${action}`,{method:"POST",headers:{"Content-Type":"application/json"},body:"{}"});activeMessage.textContent=d.message;await loadActive();}catch(e){activeMessage.textContent=e.message||"Tindakan gagal. Pastikan migrasi D1 v1.10 sudah dijalankan, lalu muat ulang panel admin.";button.disabled=false;}}
 async function decide(id,decision,button){const confirmText=decision==="approve"?"Pastikan Anda sudah memeriksa transaksi pada rekening/aplikasi QRIS. Aktifkan iklan?":"Tolak pengajuan? Iklan disembunyikan dan data beserta foto dijadwalkan untuk dihapus setelah 24 jam.";if(!confirm(confirmText))return;button.disabled=true;try{const d=await api(`/api/admin/payments/${id}/${decision}`,{method:"POST",headers:{"Content-Type":"application/json"},body:"{}"});queueMessage.textContent=d.message;await loadQueue();await loadActive();}catch(e){queueMessage.textContent=e.message||"Keputusan gagal disimpan.";button.disabled=false;}}

 async function loadPopup(){
  if(!popupMessage)return;
  popupMessage.textContent="Memuat pengaturan popup…";
  try{
   const d=await api("/api/admin/popup");
   popupActive.checked=d.popup?!!d.popup.is_active:true;
   if(d.popup?.image_url){popupPreview.src=d.popup.image_url;popupPreview.hidden=false;popupMessage.textContent="Gambar popup tersimpan. Anda dapat mengganti, menonaktifkan, atau menghapusnya.";}
   else{popupPreview.removeAttribute("src");popupPreview.hidden=true;popupMessage.textContent="Belum ada gambar popup. Unggah gambar informasi untuk ditampilkan.";}
  }catch(e){popupMessage.textContent=e.message||"Gagal memuat pengaturan popup.";}
 }
 popupFile?.addEventListener("change",()=>{
  const file=popupFile.files?.[0];
  if(!file){return;}
  if(!["image/jpeg","image/png","image/webp"].includes(file.type)||file.size>8*1024*1024){
   popupMessage.textContent="Pilih JPG, PNG, atau WebP dengan ukuran maksimal 8 MB.";
   popupFile.value="";return;
  }
  const reader=new FileReader();reader.onload=()=>{popupPreview.src=reader.result;popupPreview.hidden=false;};reader.readAsDataURL(file);
 });
 popupActive?.addEventListener("change",async()=>{
  try{const d=await api("/api/admin/popup/active",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({is_active:popupActive.checked})});popupMessage.textContent=d.message||"Status popup diperbarui.";}
  catch(e){popupActive.checked=!popupActive.checked;popupMessage.textContent=e.message||"Gagal mengubah status popup.";}
 });
 popupForm?.addEventListener("submit",async(e)=>{
  e.preventDefault();const file=popupFile.files?.[0];
  if(!file){popupMessage.textContent="Pilih gambar baru terlebih dahulu.";return;}
  if(!["image/jpeg","image/png","image/webp"].includes(file.type)||file.size>8*1024*1024){popupMessage.textContent="Format atau ukuran gambar tidak sesuai.";return;}
  savePopup.disabled=true;popupMessage.textContent="Menyiapkan unggahan gambar…";
  try{
   const signed=await api("/api/admin/popup/upload-sign",{method:"POST",headers:{"Content-Type":"application/json"},body:"{}"});
   const form=new FormData();form.append("file",file);form.append("api_key",signed.api_key);form.append("timestamp",String(signed.timestamp));form.append("folder",signed.folder);form.append("signature",signed.signature);
   const upload=await fetch(`https://api.cloudinary.com/v1_1/${signed.cloud_name}/image/upload`,{method:"POST",body:form});
   const uploaded=await upload.json();if(!upload.ok||!uploaded.secure_url||!uploaded.public_id)throw Error(uploaded.error?.message||"Upload gambar ke Cloudinary gagal.");
   const saved=await api("/api/admin/popup",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({image_url:uploaded.secure_url,public_id:uploaded.public_id,is_active:popupActive.checked})});
   popupFile.value="";popupPreview.src=saved.popup.image_url;popupPreview.hidden=false;popupMessage.textContent=saved.message||"Gambar popup berhasil disimpan.";
  }catch(e){popupMessage.textContent=e.message||"Gagal menyimpan gambar popup.";}
  finally{savePopup.disabled=false;}
 });
 deletePopup?.addEventListener("click",async()=>{
  if(!confirm("Hapus gambar popup secara permanen dari Cloudinary dan hapus catatannya dari database D1?"))return;
  deletePopup.disabled=true;popupMessage.textContent="Menghapus gambar popup…";
  try{const d=await api("/api/admin/popup",{method:"DELETE"});popupPreview.removeAttribute("src");popupPreview.hidden=true;popupFile.value="";popupActive.checked=false;popupMessage.textContent=d.message||"Gambar dan data popup berhasil dihapus.";}
  catch(e){popupMessage.textContent=e.message||"Penghapusan gagal. Data dipertahankan agar dapat dicoba kembali.";}
  finally{deletePopup.disabled=false;}
 });

 document.addEventListener("refresh-active-list",loadActive);loginForm.addEventListener("submit",login);document.getElementById("refreshQueue").addEventListener("click",()=>{loadQueue();loadActive();});document.getElementById("logout").addEventListener("click",()=>{token="";queue.replaceChildren();setLoggedIn(false);loginMessage.textContent="Anda telah keluar.";});
})();
