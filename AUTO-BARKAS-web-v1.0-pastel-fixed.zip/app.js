(() => {
 const overlay=document.getElementById('announcementOverlay'), img=document.getElementById('announcementImage'), close=document.getElementById('closeAnnouncement');
 const SHOW_EVERY_VISIT=false; // true = tampilkan popup setiap kunjungan
 let closed=false; try{closed=sessionStorage.getItem('autoBarkasInfoClosed')==='yes'}catch(e){}
 function hide(){overlay.hidden=true;try{sessionStorage.setItem('autoBarkasInfoClosed','yes')}catch(e){}}
 img.addEventListener('load',()=>{if(SHOW_EVERY_VISIT||!closed)overlay.hidden=false},{once:true});
 img.addEventListener('error',()=>{overlay.hidden=true});
 close.addEventListener('click',hide);overlay.addEventListener('click',e=>{if(e.target===overlay)hide()});document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!overlay.hidden)hide()});
 const toggle=document.getElementById('menuToggle'),nav=document.getElementById('nav');toggle.addEventListener('click',()=>{const open=nav.classList.toggle('open');toggle.setAttribute('aria-expanded',String(open))});nav.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>{nav.classList.remove('open');toggle.setAttribute('aria-expanded','false')}));
 document.getElementById('year').textContent=new Date().getFullYear();
 document.getElementById('searchForm').addEventListener('submit',e=>{e.preventDefault();const q=document.getElementById('searchInput').value.trim(),loc=document.getElementById('location').value;document.getElementById('searchMessage').textContent='Pencarian contoh: '+(q||'semua barang')+(loc?' — '+loc:'')+'. Hasil nyata akan tersedia setelah database dipasang.'});
 document.querySelectorAll('[data-category]').forEach(a=>a.addEventListener('click',()=>{document.getElementById('searchInput').value=a.dataset.category}));
 document.getElementById('understood').addEventListener('click',()=>{document.getElementById('setupMessage').textContent='Terima kasih. Formulir iklan akan dibuat pada tahap pengembangan berikutnya.'});
})();
